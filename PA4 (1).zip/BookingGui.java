package edu.century.pa4;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class BookingGui extends JFrame {
	private JPanel topPanel = new JPanel();
	//All of this on top panel
	private JLabel fNameLabel = new JLabel("First Name  ", SwingConstants.RIGHT);
	private JTextField fNameTxtField = new JTextField(5);
	
	private JLabel lNnameLabel = new JLabel("Last Name  ", SwingConstants.RIGHT);
	private JTextField lNameTxtField = new JTextField(5);
	
	private JLabel toLabel = new JLabel("To  ", SwingConstants.RIGHT);
	private JTextField toTxtField = new JTextField(5);
	
	private JLabel fromLabel = new JLabel("From  ", SwingConstants.RIGHT);
	private JTextField fromTxtField = new JTextField(10);

	private JLabel departureDate = new JLabel("Departure  ", SwingConstants.RIGHT);
	private JTextField departureTxtField = new JTextField(10);


	private JLabel returnDate = new JLabel("Return  ", SwingConstants.RIGHT);
	private JTextField returnTxtField = new JTextField(10);

	//Start of next Panel
	private JLabel seatLabel = new JLabel("Seat  ", SwingConstants.RIGHT);
	//Need to create a drop down menu for seat selection
	private String seats[] = {"1A", "1B", "1C", "1D", "2A", "2B", "2C", "2D", "3A", "3B", "3C", "3D", "4A", "4B", "4C", "4D",
			"5A", "5B", "5C", "5D","6A", "6B", "6C", "6D","7A", "7B", "7C", "7D"};
    private JComboBox seatBox = new JComboBox(seats);    
	
	private JPanel middlePanel = new JPanel();

	private JButton bookBtn = new JButton("Book");
	private JButton listBtn = new JButton("List Reservations");
	private JButton clearBtn = new JButton("Clear Console");
	
	private JPanel bottomPanel = new JPanel();
	private JTextArea consoleTxtArea = new JTextArea(5,50);
	private JScrollPane consoleScroll = new JScrollPane(consoleTxtArea);
	
	private TitledBorder borderTitle = BorderFactory.createTitledBorder("Console");
	private int ROWS = 3, COLUMNS = 1;
	
	private Reservation[] passengersList;
	private int count;


public BookingGui (String title, int size) {
	super(title);
	this.passengersList = new Reservation[size];
	setSize(800,400);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setLayout(new GridLayout(ROWS, COLUMNS));
	departureTxtField.setText("MM/DD/YYYY");
	returnTxtField.setText("MM/DD/YYYY");
	consoleScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
	addPanelsToFrame();
	createPanels();
	connectListeners();
	count = 1;
	
}

private void addPanelsToFrame() {
	add(topPanel);
	add(middlePanel);
	add(bottomPanel);
	consoleTxtArea.setBorder(borderTitle);
	
}

private void createPanels() {
	topPanel.add(fNameLabel);
	topPanel.add(fNameTxtField);
	topPanel.add(lNnameLabel);
	topPanel.add(lNameTxtField);
	topPanel.add(toLabel);
	topPanel.add(toTxtField);
	topPanel.add(fromLabel);
	topPanel.add(fromTxtField);
	topPanel.add(departureDate);
	topPanel.add(departureTxtField);
	topPanel.add(returnDate);
	topPanel.add(returnTxtField);
	topPanel.add(seatLabel);
	topPanel.add(seatBox);
	topPanel.setLayout(new GridLayout(4, 4));
	
	middlePanel.add(bookBtn);
	middlePanel.add(listBtn);
	middlePanel.add(clearBtn);
	

	bottomPanel.setLayout(new BorderLayout());
	bottomPanel.add(consoleScroll, BorderLayout.PAGE_END);
}

public void addPassengers(Reservation reservation) {
	if(reservation == null || !(reservation instanceof Reservation)) {
		System.err.println("Please try Rebooking");
		return;
	} else {
		passengersList[count] = reservation;
		count++;
	}
	
}

/*public boolean reservedSeat(Reservation targetSeat) {
	if (targetSeat == null || !(targetSeat instanceof Reservation)) {
		return false;
	}
	
		for (int i = 0; i < passengersList.length; i++) {
		if(passengersList[i].equals(targetSeat)) {
			passengersList[i] = null;
			return true;
		}
	}
	return false; 
}*/

public boolean checkSeat(String targetSeat) {
	boolean isFound = false;
	for (Reservation reservation : passengersList) {
		if (reservation != null && reservation.getSeat().equals(targetSeat)) {
			isFound = true;
			break;
		}
	}
	return isFound;
}

private void connectListeners() {
	bookBtn.addActionListener(new MyListener());
	listBtn.addActionListener(new MyListener());
	clearBtn.addActionListener(new MyListener());
}

public static void main(String[] args) {
	BookingGui gui = new BookingGui("Booking Agent", 10);
	gui.setVisible(true);
}

//need action listeners to store data entered on the gui
private class MyListener extends Reservation implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		String nameOfCallingBtn = e.getActionCommand();

		
		if (nameOfCallingBtn.equals("Book")) {
			Reservation reservation = new Reservation((String) seatBox.getSelectedItem(),  toTxtField.getText(), fromTxtField.getText()
					, departureTxtField.getText(), returnTxtField.getText(),  fNameTxtField.getText(),  lNameTxtField.getText());
			
			String targetSeat = (String) seatBox.getSelectedItem();
			boolean isFound = checkSeat(targetSeat);
			
			if (isFound) {
				consoleTxtArea.setText("We're sorry, unforunately that seat is already reserved. Please select a new seat");
			} else if (checkDate(depatureDate, returnDate)) {
				consoleTxtArea.setText("The date you have entered is invalid, please try again");
			}
			else {
				addPassengers(reservation);
				consoleTxtArea.setText("Congradulations " + fNameTxtField.getText() + ", you have booked your flight sucessfully!");	
			}
/*			if (reservedSeat(targetSeat) == false) {
				addPassengers(reservation);
				consoleTxtArea.setText("Congradulations " + fNameTxtField.getText() + ", you have booked your flight sucessfully!");	
			} else if (reservedSeat(targetSeat) == true) {
				consoleTxtArea.setText("We're sorry, unforunately that seat is already reserved. Please select a new seat");
			}
	*/
		} else if (nameOfCallingBtn.equals("List Reservations")) {
			consoleTxtArea.setText(toString() + "\n");
		}else if (nameOfCallingBtn.equals("Clear Console")) {
			consoleTxtArea.setText(null);
		}
	}
	
/*	public Reservation getTakenSeat(String seat) {
		//String takenSeat = (String) seatBox.getSelectedItem();
		for (int i = 0; i < passengersList.length; i++) {
			if (passengersList[i] != null && passengersList[i].getSeat().equals(seat)) {
				return passengersList[i];
			}
		}
		return null;
	}*/

	public boolean checkDate(String returnDate, String depatureDate) {
		DateFormat format = new SimpleDateFormat("MM, DD, yyyy", Locale.ENGLISH);
		boolean check = false;
		try {
			Date date1 = format.parse(depatureDate);
			Date date2 = format.parse(returnDate);
			if (date1.compareTo(date2) > 0) {
				check = true;
			}else {
				check = false;
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return check;
		
	}
	
	@Override
	public String toString() {
		String result = "Reservation List\n";
		int number = 1;
		for (Reservation reservation : passengersList) {
			if(reservation != null) {
				result += "***** Reservation Number: " + number + " *****" + reservation.toString()+ "\n";
				number++;
			}
		}
		return result;
		}

	}
}
