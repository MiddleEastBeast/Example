package edu.century.pa4;

public class Passengers {
	public String fName, lName;
	//boolean reservation;
	
	public Passengers() {
		
	}
	
	public Passengers(String fName, String lName) {
		setfName(fName);
		setlName(lName);
	}
	
	public String toString() {
		return "Passenger: \nFirst name: " + fName + "\nLast Name: " + lName;
	}
/*
	public boolean isReservation() {
		return reservation;
	}
	public void setReservation(boolean reservation) {
		this.reservation = reservation;
	}
	*/
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}


}
