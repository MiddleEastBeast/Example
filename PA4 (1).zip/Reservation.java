package edu.century.pa4;

import java.util.Date;

public class Reservation extends Passengers {
	public String seat;
	public String toLocation;
	public String fromLocation;
	public String depatureDate;
	public String returnDate;

	public Reservation() {
		
	}
	
	public Reservation(String seat, String toLocation, String fromLocation, String depatureDate, String returnDate, String fName, String lName) {
		super(lName, fName);
		setSeat(seat);
		setToLocation(toLocation);
		setFromLocation(fromLocation);
		setDepatureDate(depatureDate);
		setReturnDate(returnDate);
	}
	
	@Override
	public String toString() {
		
		return "\n" +  super.toString() + "\nReservation Info: \nSeat: " + seat + "\nTo: " + toLocation + "\nFrom: " + fromLocation
				+ "\nDeparture Date: " + depatureDate + "\nReturn Date: " + returnDate;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((seat == null) ? 0 : seat.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Reservation other = (Reservation) obj;
		if (seat == null) {
			if (other.seat != null)
				return false;
		} else if (!seat.equals(other.seat))
			return false;
		return true;
	}

	public String getSeat() {
		return seat;
	}

	public void setSeat(String seat) {
		this.seat = seat;
	}

	public String getToLocation() {
		return toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

	public String getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getDepatureDate() {
		return depatureDate;
	}

	public void setDepatureDate(String depatureDate) {
		this.depatureDate = depatureDate;
	}

	public String getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}
	
}
